var express = require('express');
var router = express.Router();
const apiCrown2Controller_81 = require('../controllers/apiCrown2Controller_81');

/* crown_81 */
router.get('/category_81', apiCrown2Controller_81.getCategory);
router.get('/shop_81', apiCrown2Controller_81.getShop);

/* midproj_81 */

/* finalproj_81 */

module.exports = router;
