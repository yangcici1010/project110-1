const Category_81 = require('../models/crown_81/Category_81');
const Shop_81 = require('../models/crown_81/Shop_81');

exports.getCategory = async (req, res) => {
    try {
        return await Category_81.fetchAll();
    } catch (err) {
        console.log('getCategory error', error)
    }
}

exports.getShop = async (req, res) => {
    try {
        return await Shop_81.fetchAll();
    } catch (err) {
        console.log('getCategory error', error)
    }
}